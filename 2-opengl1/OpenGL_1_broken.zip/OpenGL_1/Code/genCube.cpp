#include "mainview.h"

/*void MainView::genCube(GLuint &VAO, GLuint &VBO, GLuint &IBO) {
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &IBO);
    glGenVertexArrays(1, &VAO);

    float cubus[]{
        //x, y ,z
        // r, g, b

        //from front

        //front left
        -1,  1,  1,
         1,  0,  0,

        -1, -1,  1,
         1,  0,  0,


        // front right
         1,  1,  1,
         0,  1,  0,

         1, -1,  1,
         0,  1,  0,


        //back left
        -1,  1, -1,
         0,  0,  1,

        -1, -1, -1,
         0,  0,  1,


        // back right
         1,  1, -1,
         1,  1,  0,

         1, -1, -1,
         1,  1,  0,

    };

    GLubyte order[]{
        //order
      //top left , top right , bottom right
      //top left , bottom right , bottom left

        //vertice order; fl, fr, bl, br

        //front face
        0, 2, 3,
        0, 3, 1,

        //right face
        2, 6, 7,
        2, 7, 3,

        //back face
        6, 4, 5,
        6, 5, 7,

        //left face
        4, 0, 1,
        4, 1, 5,

        //top face
        4, 6, 2,
        4, 2, 0,

        // bottom face
        7, 5, 1,
        7, 1, 3

    };

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubus), &cubus, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(order), &order, GL_STATIC_DRAW);

    glBindVertexArray(0);
} */

/*
void MainView::genCube(GLuint &VAO, GLuint &VBO, GLuint &IBO){
    float triangle[]{
        //x, y, z
        // r, g, b
        -1,-1, 0,
         0, 1, 0,

         -1, 1, 0,
         1, 0, 0,

         1, -1, 0,
         0, 0, 1,

        1, 1, 0,
        1, 1, 1

    };

    GLubyte order[]{
        0, 2, 3,
        0, 3, 1

    };


    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(triangle) , &triangle, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(order), &order, GL_STATIC_DRAW);
}
*/

void MainView::genCube(){
    std::vector<float> square;

    square.push_back(-1);
    square.push_back( 1);
    square.push_back( 0);
    square.push_back( 0);
    square.push_back( 1);
    square.push_back( 0);


    square.push_back( 1);
    square.push_back( 1);
    square.push_back( 0);
    square.push_back( 1);
    square.push_back( 1);
    square.push_back( 1);


    square.push_back( 1);
    square.push_back(-1);
    square.push_back( 0);
    square.push_back( 0);
    square.push_back( 0);
    square.push_back( 1);


    square.push_back(-1);
    square.push_back( 1);
    square.push_back( 0);
    square.push_back( 0);
    square.push_back( 1);
    square.push_back( 0);


    square.push_back( 1);
    square.push_back(-1);
    square.push_back( 0);
    square.push_back( 1);
    square.push_back( 1);
    square.push_back( 1);


    square.push_back(-1);
    square.push_back(-1);
    square.push_back( 0);
    square.push_back( 1);
    square.push_back( 0);
    square.push_back( 0);

    glGenBuffers(1, &sphVBO);
    glGenVertexArrays(1, &sphVAO);

    glBindVertexArray(sphVAO);

    glBindBuffer(GL_ARRAY_BUFFER, sphVBO);
    glBufferData(GL_ARRAY_BUFFER, square.size() * sizeof(float) , &(square.at(0)), GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), 0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), ((GLvoid*) (3 * sizeof(GLfloat))));

}

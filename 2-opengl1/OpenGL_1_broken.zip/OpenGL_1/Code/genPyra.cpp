#include "mainview.h"

void MainView::genPyra(GLuint &VAO, GLuint &VBO, GLuint &IBO) {
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &IBO);
    glGenVertexArrays(1, &VAO);

    float pyramid[]{
        //x, y ,z
        // r, g, b

        //from front
        //peak
        0,  1,  0,
        1,  0,  0,

        //front left
        -1, -1,  1,
         1,  0,  0,


        // front right
         1, -1,  1,
         0,  1,  0,


        //back left
        -1, -1, -1,
         0,  0,  1,


        // back right
         1, -1, -1,
         1,  1,  0,

    };

    GLubyte order[]{
        //order
      //top, right, left

        //vertice order; fl, fr, bl, br

        //front face
        0, 2, 1,

        //right face
        0, 4, 2,

        //back face
        0, 3, 4,

        //left face
        0, 1, 3,

        // bottom face
        4, 3, 1,
        4, 1, 2

    };

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(pyramid), &pyramid, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(order), &order, GL_STATIC_DRAW);

    glBindVertexArray(0);

}


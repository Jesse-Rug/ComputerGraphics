#include "mainview.h"

void MainView::genObj(){
    genCube();
    genPyra();
    genSphere();
}


modifications : Added multiple optional optional parameters
		implemented additional physics laws which can be activated with optional parameters
		added support for color-textures and normalmaps
		added support for anti-alliassing 


modifications : scene file was modified to apply shading 
		raytracer file was modified to parse additional shapes
		several shapes were added
		objloader file was modified to implement unitize